"""The :mod:`pyapprox.pde` module implements numerical methods
for solving partial differential equations (PDEs).
"""
