"""The :mod:`pyapprox.pde` module implements spectral collocation methods
for solving partial differential equations (PDEs).
"""
