from pyapprox.surrogates.gaussianprocess.gaussian_process import (
    GaussianProcess, Matern
)


__all__ = ["GaussianProcess", "Matern"]
