r"""
MFNets: Multi-fidelity networks
-------------------------------
"""
